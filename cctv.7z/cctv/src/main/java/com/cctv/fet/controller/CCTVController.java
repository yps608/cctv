package com.cctv.fet.controller;

import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactoryBuilder;
import org.apache.hc.client5.http.ssl.TrustAllStrategy;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.apache.hc.core5.http.config.Http1Config;
import javax.net.ssl.SSLContext;
import org.apache.hc.core5.ssl.TrustStrategy;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CCTVController {

    @GetMapping("/api/getCCTVList")
    public String getCCTVList() {
        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadTrustMaterial(new TrustStrategy() {
                        @Override
                        public boolean isTrusted(X509Certificate[] chain, String authType) {
                            return true;
                        }
                    }).build();

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setConnectionManager(PoolingHttpClientConnectionManagerBuilder.create()
                            .setSSLSocketFactory(SSLConnectionSocketFactoryBuilder.create()
                                    .setSslContext(SSLContextBuilder.create()
                                            .loadTrustMaterial(TrustAllStrategy.INSTANCE)
                                            .build())
                                    .setHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                    .build())
                            .build())
                    .build();

            HttpPost post = new HttpPost("https://211.20.112.67:4443/login.cgi/cgi_main.cgi");
            post.setHeader("Host", "211.20.112.67:4443");
            post.setHeader("Content-Type", "Application/x-www-form-urlencoded");
            post.setHeader("Accept", "text/html, application/xhtml+xml, */*");

            String xmlData = "<?xml version=\"1.a\" encoding=\"UTF-8\"?>"
                    + "<NVSMGRREQUEST>"
                    + "<REQUESTNO>1999</REQUESTNO>"
                    + "<REQUESTNAME>rpb_play</REQUESTNAME>"
                    + "<CGINAME \"&cgiName=playback_preview.cgi&xmlData=\"/>"
                    + "<THREADID>aabbccddeeff123</THREADID>"
                    + "<RPB_PLAY>"
                    + "<PLAY_CH Ch=\"4\" SiteName=\"N04 CANON VB-H41\" MAC=\"10:bf:48:8c:27:4e\" Type=\"0\" StartTime=\"1726675200\" StopTime=\"1726739100\" Username=\"admin\" SourceMAC=\"\" />"
                    + "</RPB_PLAY>"
                    + "</NVSMGRREQUEST>";

            post.setEntity(new org.apache.hc.core5.http.io.entity.StringEntity(xmlData));

            try (CloseableHttpResponse response = httpClient.execute(post)) {
                System.out.println("HTTP Response Code: " + response.getCode());
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                System.out.println("HTTP Response: " + responseBody);
                return "getCCTVList OK";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "N/A";
    }

    @GetMapping("/api/startCCTVList")
    public String startCCTVList() {
        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadTrustMaterial(new TrustStrategy() {
                        @Override
                        public boolean isTrusted(X509Certificate[] chain, String authType) {
                            return true;
                        }
                    }).build();

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setConnectionManager(PoolingHttpClientConnectionManagerBuilder.create()
                            .setSSLSocketFactory(SSLConnectionSocketFactoryBuilder.create()
                                    .setSslContext(SSLContextBuilder.create()
                                            .loadTrustMaterial(TrustAllStrategy.INSTANCE)
                                            .build())
                                    .setHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                    .build())
                            .build())
                    .build();

            HttpPost post = new HttpPost("https://211.20.112.67:4443/login.cgi/param.cgi");
            post.setHeader("Host", "211.20.112.67:4443");
//            post.setHeader("Content-Type", "Application/x-www-form-urlencoded");
            post.setHeader("Accept", "text/html, application/xhtml+xml, */*");

            String xmlData = "action=webaction&group=pb&cmd=streaming\n" +
                    "<NVSMGRREQUEST>\n" +
                    "<REQUESTNO>1999</REQUESTNO>\n" +
                    "<REQUESTNAME>rpb_play_ch</REQUESTNAME>\n" +
                    "<REQUESTNO>1999</REQUESTNO>\n" +
                    "<THREADID>aabbccddeeff123</THREADID>\n" +
                    "<RPB_PLAY>\n" +
                    "<PLAY_CH ch=\"0\" SiteName=\"N04 CANON VB-H41\" MAC=\"10:bf:48:8c:27:4e\" SourceMAC=\"\" Type=\"0\" StartTime=\"1726675200\" StopTime=\"1726739100\" Scale=\"1\" Direction=\"1\" Offset=\"1\" TIMEZONE Bias=\"-480\" Platform=\"Web\" />\n" +
                    "</RPB_PLAY>\n" +
                    "</NVSMGRREQUEST>";
            System.out.println("xmlData = " + xmlData);
            post.setEntity(new org.apache.hc.core5.http.io.entity.StringEntity(xmlData));

            try (CloseableHttpResponse response = httpClient.execute(post)) {
                System.out.println("HTTP Response Code: " + response.getCode());
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                System.out.println("HTTP Response: " + responseBody);
                return responseBody;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "N/A";
    }

    @GetMapping("/api/controlCCTVList")
    public String controlCCTVList() {
        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadTrustMaterial(new TrustStrategy() {
                        @Override
                        public boolean isTrusted(X509Certificate[] chain, String authType) {
                            return true;
                        }
                    }).build();

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setConnectionManager(PoolingHttpClientConnectionManagerBuilder.create()
                            .setSSLSocketFactory(SSLConnectionSocketFactoryBuilder.create()
                                    .setSslContext(SSLContextBuilder.create()
                                            .loadTrustMaterial(TrustAllStrategy.INSTANCE)
                                            .build())
                                    .setHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                    .build())
                            .build())
                    .build();

            HttpPost post = new HttpPost("https://211.20.112.67:4443/login.cgi/param.cgi");
            post.setHeader("Host", "211.20.112.67:4443");
//            post.setHeader("Content-Type", "Application/x-www-form-urlencoded");
            post.setHeader("Accept", "text/html, application/xhtml+xml, */*");

            String xmlData = "action=webaction&group=pb&cmd=streaming\n" +
                    "<NVSMGRREQUEST>\n" +
                    "<REQUESTNO>1999</REQUESTNO>\n" +
                    "<REQUESTNAME>rpb_play_cmd_server</REQUESTNAME>\n" +
                    "<THREADID>aabbccddeeff123</THREADID>\n" +
                    "<Platform=\"Web\" />\n" +
                    "</NVSMGRREQUEST>";
            System.out.println("xmlData = " + xmlData);
            post.setEntity(new org.apache.hc.core5.http.io.entity.StringEntity(xmlData));

            try (CloseableHttpResponse response = httpClient.execute(post)) {
                System.out.println("HTTP Response Code: " + response.getCode());
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                System.out.println("HTTP Response: " + responseBody);
                return responseBody;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "N/A";
    }
}
