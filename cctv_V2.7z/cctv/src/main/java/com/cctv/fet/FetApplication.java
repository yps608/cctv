package com.cctv.fet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FetApplication {

	public static void main(String[] args) {
		SpringApplication.run(FetApplication.class, args);
	}

}
