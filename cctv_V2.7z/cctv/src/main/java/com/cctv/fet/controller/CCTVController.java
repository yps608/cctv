package com.cctv.fet.controller;

import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactoryBuilder;
import org.apache.hc.client5.http.ssl.TrustAllStrategy;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.apache.hc.core5.http.config.Http1Config;

import javax.net.ssl.SSLContext;

import org.apache.hc.core5.ssl.TrustStrategy;

import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CCTVController {
    private String httppost(String url, String body) {

        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadTrustMaterial(new TrustStrategy() {
                        @Override
                        public boolean isTrusted(X509Certificate[] chain, String authType) {
                            return true;
                        }
                    }).build();

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setConnectionManager(PoolingHttpClientConnectionManagerBuilder.create()
                            .setSSLSocketFactory(SSLConnectionSocketFactoryBuilder.create()
                                    .setSslContext(SSLContextBuilder.create()
                                            .loadTrustMaterial(TrustAllStrategy.INSTANCE)
                                            .build())
                                    .setHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                    .build())
                            .build())
                    .build();
            HttpPost post = new HttpPost(url);
            post.setHeader("Host", "211.20.112.67:4443");
            post.setHeader("Accept", "text/html, application/xhtml+xml, */*");
            if ("https://211.20.112.67:4443/login.cgi/cgi_main.cgi".equals(url)) {
                post.setHeader("Content-Type", "Application/x-www-form-urlencoded");
            }

            post.setEntity(new org.apache.hc.core5.http.io.entity.StringEntity(body));

            try (CloseableHttpResponse response = httpClient.execute(post)) {
                System.out.println("HTTP Response Code: " + response.getCode());
                if (response.getCode() != 200) {
                    return "Call API Fail Response Code = " + response.getCode();
                }
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                System.out.println("HTTP Response: " + responseBody);
                if ("https://211.20.112.67:4443/login.cgi/cgi_main.cgi".equals(url)) {
                    return "getCCTVList OK";
                } else {
                    return responseBody;
                }
            }
        } catch (Exception e) {
            return null;
        }
    }

    private String httpget(String url) {

        try {
            SSLContext sslContext = SSLContextBuilder.create()
                    .loadTrustMaterial(new TrustStrategy() {
                        @Override
                        public boolean isTrusted(X509Certificate[] chain, String authType) {
                            return true;
                        }
                    }).build();

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setConnectionManager(PoolingHttpClientConnectionManagerBuilder.create()
                            .setSSLSocketFactory(SSLConnectionSocketFactoryBuilder.create()
                                    .setSslContext(SSLContextBuilder.create()
                                            .loadTrustMaterial(TrustAllStrategy.INSTANCE)
                                            .build())
                                    .setHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                                    .build())
                            .build())
                    .build();
            HttpGet get = new HttpGet(url);
            get.setHeader("Host", "211.20.112.67:4443");
            get.setHeader("Accept", "text/html, application/xhtml+xml, */*");
            get.setHeader("Content-Type", "Application/x-www-form-urlencoded");


//            get.setEntity(new org.apache.hc.core5.http.io.entity.StringEntity(body));

            try (CloseableHttpResponse response = httpClient.execute(get)) {
                System.out.println("HTTP Response Code: " + response.getCode());
                if (response.getCode() != 200) {
                    return "Call API Fail Response Code = " + response.getCode();
                }
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                System.out.println("HTTP Response: " + responseBody);
                return responseBody;
            }
        } catch (Exception e) {
            return null;
        }
    }

    @GetMapping("/api/refreshCCTV")
    public String refreshCCTV() {
        String url = "https://211.20.112.67:4443/login.cgi/param.cgi?action=webaction&group=pb&cmd=ack&uuid=aabbccddeeff123";
        return httpget(url);
    }

    @GetMapping("/api/getm3u8")
    public String getm3u8() {
        String url = "https://211.20.112.67:4443/hls/pb/aabbccddeeff123_playlist_CH0.m3u8";
        return httpget(url);
    }

    @PostMapping("/api/getCCTVList")
    public String getCCTVList() {
        try {
            String xmlData = "<?xml version=\"1.a\" encoding=\"UTF-8\"?>"
                    + "<NVSMGRREQUEST>"
                    + "<REQUESTNO>1999</REQUESTNO>"
                    + "<REQUESTNAME>rpb_play</REQUESTNAME>"
                    + "<CGINAME \"&cgiName=playback_preview.cgi&xmlData=\"/>"
                    + "<THREADID>aabbccddeeff123</THREADID>"
                    + "<RPB_PLAY>"
                    + "<PLAY_CH Ch=\"4\" SiteName=\"N04 CANON VB-H41\" MAC=\"10:bf:48:8c:27:4e\" Type=\"0\" StartTime=\"1726675200\" StopTime=\"1726739100\" Username=\"admin\" SourceMAC=\"\" />"
                    + "</RPB_PLAY>"
                    + "</NVSMGRREQUEST>";
            String url = "https://211.20.112.67:4443/login.cgi/cgi_main.cgi";
            return httppost(url, xmlData);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "N/A";
    }

    @PostMapping("/api/startCCTVList")
    public String startCCTVList() {
        String url = "https://211.20.112.67:4443/login.cgi/param.cgi";
        String xmlData = "action=webaction&group=pb&cmd=streaming\n" +
                "<NVSMGRREQUEST>\n" +
                "<REQUESTNO>1999</REQUESTNO>\n" +
                "<REQUESTNAME>rpb_play_ch</REQUESTNAME>\n" +
                "<REQUESTNO>1999</REQUESTNO>\n" +
                "<THREADID>aabbccddeeff123</THREADID>\n" +
                "<RPB_PLAY>\n" +
                "<PLAY_CH ch=\"0\" SiteName=\"N04 CANON VB-H41\" MAC=\"10:bf:48:8c:27:4e\" SourceMAC=\"\" Type=\"0\" StartTime=\"1726675200\" StopTime=\"1726739100\" Scale=\"1\" Direction=\"1\" Offset=\"1\" TIMEZONE Bias=\"-480\" Platform=\"Web\" />\n" +
                "</RPB_PLAY>\n" +
                "</NVSMGRREQUEST>";
        return httppost(url, xmlData);
    }

    @PostMapping("/api/controlCCTVList")
    public String controlCCTVList() {
        String url = "https://211.20.112.67:4443/login.cgi/param.cgi";
        String xmlData = "action=webaction&group=pb&cmd=streaming\n" +
                "<NVSMGRREQUEST>\n" +
                "<REQUESTNO>1999</REQUESTNO>\n" +
                "<REQUESTNAME>rpb_play_cmd_server</REQUESTNAME>\n" +
                "<THREADID>aabbccddeeff123</THREADID>\n" +
                "<Platform=\"Web\" />\n" +
                "</NVSMGRREQUEST>";
        return httppost(url, xmlData);

    }

}
